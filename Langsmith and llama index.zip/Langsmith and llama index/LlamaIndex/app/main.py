from fastapi import FastAPI, UploadFile, Form
from app.services import build_index, query_index
import os

app = FastAPI(
    title="LlamaIndex API",
    description="API for indexing documents and querying using LlamaIndex.",
    version="1.0.0",
)

UPLOAD_DIR = "./data"


@app.post("/upload-documents/")
async def upload_documents(files: list[UploadFile]):
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    for file in files:
        file_path = os.path.join(UPLOAD_DIR, file.filename)
        with open(file_path, "wb") as f:
            f.write(file.file.read())
    return {"message": "Files uploaded successfully."}


@app.post("/build-index/")
async def create_index():
    index = build_index(UPLOAD_DIR)
    index.storage_context.persist("./index_storage")
    return {"message": "Index built and stored successfully."}


@app.get("/query/")
async def ask_question(question: str = Form(...)):
    from llama_index import load_index_from_storage

    index = load_index_from_storage("./index_storage")
    answer = query_index(index, question)
    return {"question": question, "answer": answer}
