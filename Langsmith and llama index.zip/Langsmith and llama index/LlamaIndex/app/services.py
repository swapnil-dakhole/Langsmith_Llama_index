import os

from langchain.chat_models import ChatOpenAI
from llama_index import (
    GPTVectorStoreIndex,
    LLMPredictor,
    PromptHelper,
    ServiceContext,
    SimpleDirectoryReader,
)

# Directly set the OpenAI API Key
OPENAI_API_KEY = "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"

# Set the environment variable for compatibility with libraries expecting it
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

MODEL_NAME = "gpt-3.5-turbo"

# Define the LLM and LlamaIndex service context
llm = ChatOpenAI(
    model_name=MODEL_NAME,
    openai_api_key=OPENAI_API_KEY,  # Use the direct API key
)

# Helper to limit token usage
prompt_helper = PromptHelper(
    context_window=4096,  # Replace max_input_size with context_window
    num_output=256,
    chunk_overlap_ratio=0.1,  # Optional: Use a ratio for chunk overlap
)

# Set up LlamaIndex service context
service_context = ServiceContext.from_defaults(
    llm_predictor=LLMPredictor(llm=llm), prompt_helper=prompt_helper
)


def build_index(directory: str):
    """Load documents and create a GPT VectorStoreIndex."""
    documents = SimpleDirectoryReader(directory).load_data()
    index = GPTVectorStoreIndex.from_documents(
        documents, service_context=service_context
    )
    return index


def query_index(index, question: str):
    """Query the GPT VectorStoreIndex for answers."""
    query_engine = index.as_query_engine()
    response = query_engine.query(question)
    return response.response


# Example Usage
if __name__ == "__main__":
    directory = "path/to/your/documents"  # Replace with your documents folder
    question = "What is the summary of the documents?"

    index = build_index(directory)
    answer = query_index(index, question)
    print(answer)
