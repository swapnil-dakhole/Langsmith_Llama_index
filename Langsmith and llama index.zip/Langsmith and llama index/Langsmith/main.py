import os
import json
import streamlit as st
from dotenv import load_dotenv
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI

# Load environment variables
load_dotenv()

# Set API keys
os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY")
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_API_KEY"] = os.getenv("LANGCHAIN_API_KEY")
os.environ["LANGCHAIN_PROJECT"] = "Funny Answer Bot"

# Define the humorous prompt template
prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a funny assistant. Please respond to the user's question in a humorous way with one-sentence answers.",
        ),
        ("user", "Question: {question}"),
    ]
)

# Initialize the model
model = ChatOpenAI(model="gpt-3.5-turbo")

# Set up the output parser
output_parser = StrOutputParser()

# Define the chain
chain = prompt | model | output_parser

# File to store history
history_file = "question_response_history.json"


# Function to load history from file
def load_history():
    if os.path.exists(history_file):
        with open(history_file, "r") as f:
            return json.load(f)
    return []


# Function to save history to file
def save_history(history):
    with open(history_file, "w") as f:
        json.dump(history, f, indent=4)


# Load existing history from the file
history = load_history()

# Streamlit app setup
st.title("Funny Answer Bot")

# Set up the session state for the question input if it doesn't exist
if "question" not in st.session_state:
    st.session_state["question"] = ""

# User input for the question
question = st.text_input(
    "Ask a funny question:", value=st.session_state["question"], key="question_input"
)

# If the user submits a question
if st.button("Submit"):
    if question:
        # Get the response from the chain
        response = chain.invoke({"question": question})

        # Save the question and response to the history
        history.append({"question": question, "response": response})
        save_history(history)  # Save history to the file

        # Clear the question input field by resetting the session state
        st.session_state["question"] = ""

# Display the history of questions and responses in reverse order
st.subheader("Previous Questions and Responses (Most Recent First)")
for item in history[::-1]:  # Reverse the list
    st.write(f"**Q**: {item['question']}")
    st.write(f"**A**: {item['response']}")
